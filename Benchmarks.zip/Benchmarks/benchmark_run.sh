#!/bin/bash
# file name: benchmark_run.sh

mkdir results

echo "Running 100 nodes test"
cat > results/100nodes_test.txt << EOF1
100 node test
20 tests
EOF1
{ time ./benchmark_run_100nodes.sh; } 2>> results/100nodes_test.txt
echo "Done 100 nodes"

echo "Running 200 nodes test"
cat > results/200nodes_test.txt << EOF1
200 node test
20 tests
EOF1
{ time ./benchmark_run_200nodes.sh; } 2>> results/200nodes_test.txt
echo "Done 200 nodes"

echo "Running 500 nodes test"
cat > results/500nodes_test.txt << EOF1
500 node test
10 tests
EOF1
{ time ./benchmark_run_500nodes.sh; } 2>> results/500nodes_test.txt
echo "Done 500 nodes"
